import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import static java.lang.Math.abs;

public class Main {

        static int lives = 3;
        static long time_millis;
        static int score = 0;
        static boolean end=false;

        static long startTime;


        public static void endGame(){               // Funkcja końca rozgrywki

        }

        public static void question(){              // Funkcja wyświetlająca pytanie dla gracza

        }

        public static void main(String[] args) throws IOException {
            System.setProperty("sun.awt.noerasebackground", "true");
            CreateMenu Menu = new CreateMenu();
            Menu.showGUI();
            Menu.board.setVisible(true);
            Menu.difficulty=3;

            JLabel scoreLabel = new JLabel();                                   // Wyświetlanie timera na górze menu
            scoreLabel.setForeground(Color.WHITE);
            scoreLabel.setFont(new Font("Arial", Font.BOLD, 40));
            scoreLabel.setBounds(600, 25, 300, 50);
            Menu.pasek.add(scoreLabel);

            JLabel timerLabel = new JLabel();                                   // Wyświetlanie timera na górze menu
            timerLabel.setForeground(Color.WHITE);
            timerLabel.setFont(new Font("Arial", Font.BOLD, 40));
            timerLabel.setBounds(250, 25, 300, 50);
            Menu.pasek.add(timerLabel);
            startTime= System.currentTimeMillis();

            JLabel livesText = new JLabel();
            livesText.setForeground(Color.WHITE);
            livesText.setFont(new Font("Arial", Font.BOLD, 40));
            livesText.setBounds(870, 25, 300, 50);
            Menu.pasek.add(livesText);

            String imagePath1 = "/heart1.png";
            InputStream url = Main.class.getResourceAsStream(imagePath1);
            BufferedImage heart = ImageIO.read(url);

            JLabel livesLabel = new JLabel(new ImageIcon(heart));
            livesLabel.setBounds(1000, 1, 100, 100);
            Menu.pasek.add(livesLabel);

            JLabel livesLabel2 = new JLabel(new ImageIcon(heart));
            livesLabel2.setBounds(1070, 1, 100, 100);
            Menu.pasek.add(livesLabel2);

            JLabel livesLabel3 = new JLabel(new ImageIcon(heart));
            livesLabel3.setBounds(1140, 1, 100, 100);
            Menu.pasek.add(livesLabel3);

            switch(Menu.difficulty){
                case 1:
                {
                 time_millis = 2000;
                 break;
                }
                case 2:
                {
                    time_millis = 1000;
                    break;
                }
                case 3:
                {
                    time_millis = 500;
                    break;
                }

            }
            ScheduledExecutorService executorService2 = Executors.newSingleThreadScheduledExecutor(); // Funkcja wykonuje się cyklicznie, co zadany czas (zmienna difficulty)
            executorService2.scheduleWithFixedDelay(() -> {
                try {
                    Menu.clickableDrawing();    // Rysuje czerwone klikalne pole
                    //score++;
                    //lives--;
                }   catch (Exception e) {
                    e.printStackTrace();
                }

            }, 0, time_millis, TimeUnit.MILLISECONDS);

               ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor(); // Funkcja wykonuje się cyklicznie co 50 ms (odświeżanie ekranu)
                executorService.scheduleWithFixedDelay(() -> {
                    try {
                        updateTimer(timerLabel);
                        updateScore(scoreLabel);
                        updateLives(livesText);
                        switch(lives){
                            case 3:
                            {
                                livesLabel.repaint();
                                livesLabel2.repaint();
                                livesLabel3.repaint();
                                Menu.pasek.repaint();
                                break;
                            }
                            case 2:
                            {
                                livesLabel.repaint();
                                livesLabel2.repaint();
                                Menu.pasek.remove(livesLabel3);
                                Menu.pasek.repaint();
                                break;
                            }
                            case 1:
                            {
                                livesLabel.repaint();
                                Menu.pasek.remove(livesLabel2);
                                Menu.pasek.remove(livesLabel3);
                                Menu.pasek.repaint();
                                break;
                            }
                            case 0:{
                                Menu.pasek.remove(livesLabel);
                                Menu.pasek.remove(livesLabel2);
                                Menu.pasek.remove(livesLabel3);
                                Menu.pasek.repaint();
                            }
                        }

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }, 0, 50, TimeUnit.MILLISECONDS);


        }

    public static void updateTimer(JLabel timerLabel) {
        long elapsedTime = System.currentTimeMillis() - startTime;
        long seconds = elapsedTime / 1000;
        long minutes = seconds / 60;

        SimpleDateFormat sdf = new SimpleDateFormat("mm:ss");
        String formattedTime = sdf.format(elapsedTime);

        SwingUtilities.invokeLater(() -> {
            timerLabel.setText("Czas: " + formattedTime);
            timerLabel.repaint();
        });
    }

    public static void updateScore(JLabel scoreLabel){
        scoreLabel.setText("Wynik: "+ score);
    }

    public static void updateLives(JLabel livesText){
            livesText.setText("Życia: ");
    }


}
