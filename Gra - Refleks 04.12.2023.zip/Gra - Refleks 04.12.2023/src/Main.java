import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
    public class Main {

        static int lives = 3;
        static long time_millis;
        static int score = 0;
        static boolean end=false;

        public static void endGame(){               // Funkcja końca rozgrywki

        }

        public static void question(){              // Funkcja wyświetlająca pytanie dla gracza

        }

        public static void main(String[] args) {

            CreateMenu Menu = new CreateMenu();
            Menu.showGUI();
            Menu.board.setVisible(true);

            //DrawClickTargets drawClick = new DrawClickTargets();
            //Menu.board.add(drawClick);

            //Menu.board.revalidate();

            // Gdzieś tutaj powinien być aktualizowany czas do przekazania do metody updateMenu

            while(end==false){          // end == true oznacza koniec gry i funkcję zakończenia rozgrywki
               Menu.updateMenu(lives,score, false,time_millis);

            }
            endGame();

        }

    }
