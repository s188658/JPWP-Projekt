import javax.swing.*;
import java.awt.*;


public class DrawClickTargets extends JPanel {
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        System.out.println("Dziala");
        int n = Target.createClickTargets();
        int x = Target.clickTargets[n].x;
        int y = Target.clickTargets[n].y;
        boolean hit = Target.clickTargets[n].hit;

        g.setColor(Color.RED);
        g.fillOval(x,y,100, 100);

    }
}
