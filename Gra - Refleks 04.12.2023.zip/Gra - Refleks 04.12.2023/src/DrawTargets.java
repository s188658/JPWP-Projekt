import javax.swing.*;
import java.awt.*;



public class DrawTargets extends JPanel {

    @Override
    protected void paintComponent(Graphics g) {                 // Metoda rysująca tylko szare pola
        super.paintComponent(g);

        Target.createTargets();
        //Target.checkTargets();                                // Funkcja wyświetlająca w konsoli lokalizacje pól

        for (int i = 0; i<35; i++){

            int x = Target.targets[i].x;
            int y = Target.targets[i].y;

            g.setColor(Color.LIGHT_GRAY);
            g.fillOval(x,y,100, 100);
        }

    }

}
