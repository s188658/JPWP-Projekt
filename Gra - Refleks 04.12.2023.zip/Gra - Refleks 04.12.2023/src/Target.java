import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class Target {
    int x;
    int y;
    static int count;

    int status;
    boolean hit;
    public static Target[] targets = new Target[35];
    public static Target[] clickTargets = new Target [35];
    Target(int x, int y, boolean hit, int status) {             // Konstruktor klasy target
        this.x = x;
        this.y = y;
        this.hit = hit;
        this.status = status;
    }
    public static void createTargets() {            // Metoda tworzy szare pola, na których będą wyświetlać się cele

        for (int i = 0; i < 35; i++) {
            targets[i] = new Target(118 + (124 * (i % 7)), 50 + (124 * (i % 5)), false, 0);
        }
    }

    public static int createClickTargets(){
        Random rand = new Random();
        int n = rand.nextInt(35)+1;
        int x_pos = targets[n].x;
        int y_pos = targets[n].y;
        clickTargets[n] = new Target(x_pos,y_pos,false,1);
        count++;
        System.out.println(n);
        return (n);

    }
    public static void checkTargets(){
        for (int i = 0; i < 35; i++) {
            System.out.print((i+1)+" "+targets[i].x +" "+ targets[i].y + "\n");
        }
    }
}



