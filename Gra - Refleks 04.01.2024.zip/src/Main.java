import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import static java.lang.Math.abs;

public class Main implements MouseListener {

        static int lives = 3;
        static long time_millis;
        static int score = 0;
        static boolean end=false;



        public static void endGame(){               // Funkcja końca rozgrywki

        }

        public static void question(){              // Funkcja wyświetlająca pytanie dla gracza

        }

        public static void main(String[] args) {
            System.setProperty("sun.awt.noerasebackground", "true");
            CreateMenu Menu = new CreateMenu();
            Menu.showGUI();
            Menu.board.setVisible(true);
            Menu.difficulty=1;


            switch(Menu.difficulty){
                case 1:
                {
                 time_millis = 2000;
                }
                case 2:
                {
                    time_millis = 1000;
                }
                case 3:
                {
                    time_millis = 2000;
                }

            }

            while(end==false){          // end == true oznacza koniec gry i funkcję zakończenia rozgrywki
               //Menu.updateMenu(lives,score, false,time_millis);

               try {
                    Thread.sleep(time_millis);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                Menu.clickableDrawing();                  // Rysuje czerwone klikalne pole
            }
            endGame();

        }

    @Override
    public void mouseClicked(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();

        int n = Target.pos_tab;

        if(abs(Target.clickTargets[n].x+50-x)<50 && abs(Target.clickTargets[n].y+50-y)<50){
            Target.clickTargets[n].hit =true;
            System.out.println("Trafiono");
        }
        else{
            lives--;
            System.out.println("Życia: "+lives);
        }

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
