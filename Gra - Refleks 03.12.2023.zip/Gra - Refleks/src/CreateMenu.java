
import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;

public class CreateMenu {
    public static void showGUI() {                                  // Funkcja wyświetla Gui na ekranie
        JFrame board = new JFrame();                                // Frame - kontener na wszystko inne
        board.setResizable(false);
        board.setSize(1280, 832);
        board.setTitle("Refleks - Maciej Politowski 188658");
        board.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        board.getContentPane().setBackground(new Color(255, 255, 255));

        DrawTargets draw = new DrawTargets();                       // Funkcja odpowiedzialna za wyświtlanie na ekranie celów
        board.add(draw);


        JPanel pasek = new JPanel();                                   // Górny pasek menu
        pasek.setPreferredSize(new Dimension(1280, 100));
        pasek.setBackground(Color.DARK_GRAY);
        pasek.setBorder(new LineBorder(Color.BLACK));
        pasek.setVisible(true);
        board.add(pasek, BorderLayout.NORTH);

        JPanel sidemenu = new JPanel();                                     // Menu boczne
        sidemenu.setPreferredSize(new Dimension(200, 720));
        sidemenu.setBackground(Color.DARK_GRAY);
        sidemenu.setBorder(new LineBorder(Color.BLACK));
        sidemenu.setVisible(true);
        board.add(sidemenu, BorderLayout.WEST);


        /* JLabel timer = new JLabel();                                        // Dodanie timera do paska
        timer.setText("Timer");
        timer.setLocation(1100, 75);
        timer.setFont(new Font("Verdana", 1, 50));
        timer.setVisible(true);
        pasek.add(timer);
        */
        board.setVisible(true);             // Wyświetla zainicjalizowane menu na planszy
    }




}
