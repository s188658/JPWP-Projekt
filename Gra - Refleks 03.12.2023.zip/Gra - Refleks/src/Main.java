import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.image.ImageObserver;
import java.text.AttributedCharacterIterator;

    public class Main {
        public static void main(String[] args) {

            CreateMenu Menu = new CreateMenu();
            Menu.showGUI();


        }
    }
