public class Timer {

    public static long timer() {
        return 0;
    }
}
