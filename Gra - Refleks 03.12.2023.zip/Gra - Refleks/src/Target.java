import javax.swing.*;
import java.awt.*;

public class Target {
    int x;
    int y;
    String color;
    public static Target[] targets = new Target[35];

    Target(int x, int y, String color) {
        this.x = x;
        this.y = y;
        this.color = color;
    }
    public static void createTargets() {

        for (int i = 0; i < 35; i++) {
            targets[i] = new Target(118 + (124 * (i % 7)), 50 + (124 * (i % 5)), "DARK_GRAY");
        }
    }
    public static void checkTargets(){
        for (int i = 0; i < 35; i++) {
            System.out.print((i+1)+" "+targets[i].x +" "+ targets[i].y + "\n");
        }
    }
}



