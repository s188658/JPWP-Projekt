import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;


public class CreateMenu implements ActionListener, MouseListener {
    JButton menuButton;

    int menuButtonclick = 0;

    int difficulty = 0;
    JButton easy;
    JButton intermediate;
    JButton hard;

    JButton exit;

    JFrame board = new JFrame();
    JPanel pasek = new JPanel();
    JPanel sidemenu = new JPanel();
    DrawTargets draw = new DrawTargets();
    public int showGUI()  {                                  // Funkcja wyświetla Gui na ekranie

        board.addMouseListener(this);


        board.setResizable(false);
        board.setSize(1280, 832);
        board.setTitle("Refleks - Maciej Politowski 188658");
        board.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        board.setUndecorated(true);

        board.getContentPane().setBackground(new Color(255, 255, 255));

                                           // Górny pasek menu
        pasek.setPreferredSize(new Dimension(1280, 100));
        pasek.setBackground(Color.DARK_GRAY);
        pasek.setBorder(new LineBorder(Color.BLACK));
        pasek.setVisible(true);
        pasek.setLayout(null);

        board.add(pasek, BorderLayout.NORTH);

                                             // Menu boczne
        sidemenu.setPreferredSize(new Dimension(200, 720));
        sidemenu.setBackground(Color.DARK_GRAY);
        sidemenu.setBorder(new LineBorder(Color.BLACK));
        board.add(sidemenu, BorderLayout.WEST);

        menuButton = new JButton();
        menuButton.setPreferredSize(new Dimension(180,50));
        menuButton.addActionListener(this);
        menuButton.setText("MENU");
        sidemenu.add(menuButton);
        sidemenu.setVisible(true);


        //board.add(draw);            // Funkcja odpowiedzialna za wyświtlanie na ekranie celów
        board.setVisible(true);     // Wyświetla zainicjalizowane menu na planszy
        return(0);
    }

    @Override
    public void actionPerformed(ActionEvent e) {                    // Menu po kliknieciu przycisku Menu
        if(menuButtonclick==0){
            if (e.getSource() == menuButton) {
                easy = new JButton();
                intermediate = new JButton();
                hard = new JButton();
                exit = new JButton();

                JLabel pusty = new JLabel("____________________________");      //Linia oddzielająca
                pusty.setFont(new Font("Verdana", 1, 20));
                pusty.setForeground(Color.black);
                sidemenu.add(pusty);

                JLabel poziom = new JLabel("Wybor poziomu trudnosci:");         //Napis
                poziom.setFont(new Font("Verdana", 1, 13));
                poziom.setForeground(Color.white);
                sidemenu.add(poziom);

                easy.setPreferredSize(new Dimension(100, 50));          //Poziom łatwy
                easy.addActionListener(this);
                easy.setText("Latwy");
                easy.addActionListener(
                        new ActionListener() {
                            public void actionPerformed(ActionEvent e) {
                                difficulty=1;
                                Main.lives=3;
                                Main.startTime=System.currentTimeMillis();
                                Main.score=0;

                            }
                        }
                );
                sidemenu.add(easy);

                intermediate.setPreferredSize(new Dimension(100, 50));     //Poziom średni
                intermediate.addActionListener(this);
                intermediate.setText("Sredni");
                intermediate.addActionListener(
                        new ActionListener() {
                            public void actionPerformed(ActionEvent e) {
                                difficulty=2;
                                Main.lives=3;
                                Main.startTime=System.currentTimeMillis();
                                Main.score=0;

                            }
                        }
                );
                sidemenu.add(intermediate);

                hard.setPreferredSize(new Dimension(100, 50));        //Poziom trudny
                hard.addActionListener(this);
                hard.setText("Trudny");
                hard.addActionListener(
                        new ActionListener() {
                            public void actionPerformed(ActionEvent e) {
                                difficulty=3;
                                Main.lives=3;
                                Main.startTime=System.currentTimeMillis();
                                Main.score=0;

                            }
                        }
                );
                sidemenu.add(hard);

                JLabel pusty2 = new JLabel("____________________________");        //Linia oddzielająca
                pusty2.setFont(new Font("Verdana", 1, 20));
                pusty2.setForeground(Color.black);
                sidemenu.add(pusty2);

                JLabel wyjscie = new JLabel("Inne Opcje:");                         // Napis
                wyjscie.setFont(new Font("Verdana", 1, 13));
                wyjscie.setForeground(Color.white);
                sidemenu.add(wyjscie);


                exit.setPreferredSize(new Dimension(180, 50));          //Przycisk wyjścia z programu
                exit.addActionListener(this);
                exit.setText("Wyjscie z gry");
                exit.addActionListener(
                        new ActionListener() {
                            public void actionPerformed(ActionEvent e) {
                                if (JOptionPane.showConfirmDialog( board,"Czy na pewno chcesz wyjsc z gry?","Refleks",
                                        JOptionPane.YES_NO_OPTION)==JOptionPane.YES_OPTION)
                                    System.exit(0);
                            }
                        }
                );
                sidemenu.add(exit);


                sidemenu.revalidate();
                menuButtonclick++;
            }
        }

    }

    public void clickableDrawing(){
        DrawTargets Pole = new DrawTargets();
        board.add(Pole);
        board.revalidate();
    }


    @Override
    public void mouseClicked(MouseEvent e) {                // Metoda odpowiada za wykrycie kliknięcia myszką na punkt

    }

    @Override
    public void mousePressed(MouseEvent e) {
        int x = e.getX()-200;
        int y = e.getY()-100;
        int n;
       


        if(x>0 && y>0) {
            n = Target.pos_tab;

            if (x>Target.clickTargets[n].x && x< Target.clickTargets[n].x+100 && y>Target.clickTargets[n].y && y<Target.clickTargets[n].y+100) {

                Target.clickTargets[n].hit = true;
                Main.score++;
                ReDrawTargets reDraw = new ReDrawTargets();
                board.add(reDraw);
                board.revalidate();


            } else {
                Main.lives--;
            }
        }

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
