import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;


public class Main {

    static int lives = 3;
    static long time_millis=0;

    static long time;
    static int score = 0;
    static boolean end = false;

    static long startTime;


    public static void main(String[] args) throws IOException {
        System.setProperty("sun.awt.noerasebackground", "true");
        CreateMenu Menu = new CreateMenu();
        Menu.showGUI();
        Menu.board.setVisible(true);

        JLabel scoreLabel = new JLabel();                                   // Wyświetlanie timera na górze menu
        scoreLabel.setForeground(Color.WHITE);
        scoreLabel.setFont(new Font("Arial", Font.BOLD, 40));
        scoreLabel.setBounds(600, 25, 300, 50);
        Menu.pasek.add(scoreLabel);

        JLabel timerLabel = new JLabel();                                   // Wyświetlanie timera na górze menu
        timerLabel.setForeground(Color.WHITE);
        timerLabel.setFont(new Font("Arial", Font.BOLD, 40));
        timerLabel.setBounds(300, 25, 300, 50);
        Menu.pasek.add(timerLabel);
        startTime = System.currentTimeMillis();

        JLabel livesText = new JLabel();
        livesText.setForeground(Color.WHITE);
        livesText.setFont(new Font("Arial", Font.BOLD, 40));
        livesText.setBounds(870, 25, 300, 50);
        Menu.pasek.add(livesText);

        String imagePath1 = "/heart1.png";
        InputStream url = Main.class.getResourceAsStream(imagePath1);
        BufferedImage heart = ImageIO.read(url);

        JLabel livesLabel = new JLabel(new ImageIcon(heart));
        livesLabel.setBounds(1000, 1, 100, 100);
        Menu.pasek.add(livesLabel);

        JLabel livesLabel2 = new JLabel(new ImageIcon(heart));
        livesLabel2.setBounds(1070, 1, 100, 100);
        Menu.pasek.add(livesLabel2);

        JLabel livesLabel3 = new JLabel(new ImageIcon(heart));
        livesLabel3.setBounds(1140, 1, 100, 100);
        Menu.pasek.add(livesLabel3);

        JLabel levelLabel = new JLabel();
        levelLabel.setForeground(Color.WHITE);
        levelLabel.setFont(new Font("Arial", Font.BOLD, 40));
        levelLabel.setBounds(20, 25, 300, 50);
        Menu.pasek.add(levelLabel);

        JLabel Init = new JLabel();
        Init.setForeground(Color.WHITE);
        Init.setFont(new Font("Arial", Font.BOLD, 20));
        Init.setBounds(20, 25, 1200, 50);
        Init.setText("Aby rozpoczac gre nalezy wybrac poziom trudnosci: Menu -> Wybor poziomu trudnosci :)");
        Menu.pasek.add(Init);


        while(time_millis == 0) {
            Init.repaint();
            switch (Menu.difficulty) {
                case 1: {
                    time_millis = 2000;
                    break;
                }
                case 2: {
                    time_millis = 1500;
                    break;
                }
                case 3: {
                    time_millis = 1000;
                    break;
                }
            }
        }
        DrawTargets draw = new DrawTargets();
        Menu.board.add(draw);            // Funkcja odpowiedzialna za wyświtlanie na ekranie celów
        Menu.pasek.remove(Init);
        ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor(); // Funkcja wykonuje się cyklicznie co 50 ms (odświeżanie ekranu)
        executorService.scheduleWithFixedDelay(() -> {
            try {


                updateTimer(timerLabel);
                updateScore(scoreLabel);
                updateLives(livesText);
                levelLabel.setText("Poziom: "+Menu.difficulty);


                switch (lives) {
                    case 3: {
                        Menu.pasek.add(livesLabel3);
                        Menu.pasek.add(livesLabel2);
                        Menu.pasek.add(livesLabel);
                        livesLabel.repaint();
                        livesLabel2.repaint();
                        livesLabel3.repaint();
                        Menu.pasek.repaint();
                        break;
                    }
                    case 2: {
                        livesLabel.repaint();
                        livesLabel2.repaint();
                        Menu.pasek.remove(livesLabel3);
                        Menu.pasek.repaint();
                        break;
                    }
                    case 1: {
                        livesLabel.repaint();
                        Menu.pasek.remove(livesLabel2);
                        Menu.pasek.remove(livesLabel3);
                        Menu.pasek.repaint();
                        break;
                    }
                    case 0: {
                        Menu.pasek.remove(livesLabel);
                        Menu.pasek.remove(livesLabel2);
                        Menu.pasek.remove(livesLabel3);
                        Menu.pasek.repaint();
                    }
                }
                if (lives == 0) {
                    long current_time;
                    current_time = System.currentTimeMillis();
                    long initial_start;
                    initial_start = startTime;
                    SimpleDateFormat sdf = new SimpleDateFormat("mm:ss");
                    String formattedTime = sdf.format(current_time-initial_start);
                    JOptionPane.showMessageDialog(null, "Zakonczono gre z wynikiem: "+score+" w czasie: "+formattedTime, "Koniec gry!", JOptionPane.INFORMATION_MESSAGE);

                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd_HH_mm");
                    String fileName = "Wyniki_" + dateFormat.format(new Date()) + ".txt";

                    try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {


                        writer.write("Trudnosc: "+Menu.difficulty);
                        writer.newLine();
                        writer.write("Wynik: "+score);
                        writer.newLine();
                        writer.write("Czas: "+formattedTime);
                        writer.newLine();

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    System.exit(1);
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }, 0, 50, TimeUnit.MILLISECONDS);



        ScheduledExecutorService executorService2 = Executors.newSingleThreadScheduledExecutor(); // Funkcja wykonuje się cyklicznie, co zadany czas (zmienna difficulty)
        executorService2.scheduleWithFixedDelay(() -> {
            try {
                if (Target.clickTargets[Target.pos_tab].hit == false) {
                    lives--;
                }
                Menu.clickableDrawing();    // Rysuje czerwone klikalne pole


            } catch (Exception e) {
                e.printStackTrace();
            }

        }, time_millis, time_millis, TimeUnit.MILLISECONDS);


    }

    public static void updateTimer(JLabel timerLabel) {
        long elapsedTime = System.currentTimeMillis() - startTime;
        long seconds = elapsedTime / 1000;
        long minutes = seconds / 60;

        SimpleDateFormat sdf = new SimpleDateFormat("mm:ss");
        String formattedTime = sdf.format(elapsedTime);

        SwingUtilities.invokeLater(() -> {
            timerLabel.setText("Czas: " + formattedTime);
            timerLabel.repaint();
        });
    }

    public static void updateScore(JLabel scoreLabel) {
        scoreLabel.setText("Wynik: " + score);
    }

    public static void updateLives(JLabel livesText) {
        livesText.setText("zycia: ");
    }


}
