import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class Target {
    int x;
    int y;
    static int count;

    static int pos_tab;

    int status;
    boolean hit;
    public static Target[] targets = new Target[35];
    public static Target[] clickTargets = new Target [35];
    Target(int x, int y, boolean hit, int status) {             // Konstruktor klasy target
        this.x = x;
        this.y = y;
        this.hit = hit;
        this.status = status;
    }
    public static void createTargets() {            // Metoda tworzy szare pola, na których będą wyświetlać się cele

        for (int i = 0; i < 35; i++) {
            targets[i] = new Target(118 + (124 * (i % 7)), 50 + (124 * (i % 5)), false, 0);
        }
    }

    public static int createClickTargets(){                 //Metoda tworzy pola do klikania
        Random rand = new Random();
        int n = rand.nextInt(35);
        int x_pos = targets[n].x;
        int y_pos = targets[n].y;
        clickTargets[count] = new Target(x_pos,y_pos,false,1);
        pos_tab = count;
        count++;
        return (pos_tab);


    }
    public static void checkTargets(){                      // Metoda do sprawdzania generowanych pól
        for (int i = 0; i < 35; i++) {
            System.out.print((i+1)+" "+targets[i].x +" "+ targets[i].y + "\n");
        }
    }
}



