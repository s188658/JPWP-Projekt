import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import static java.lang.Math.abs;

public class Main {

        static int lives = 3;
        static long time_millis;
        static int score = 0;
        static boolean end=false;

        static long startTime;


        public static void endGame(){               // Funkcja końca rozgrywki

        }

        public static void question(){              // Funkcja wyświetlająca pytanie dla gracza

        }

        public static void main(String[] args) throws IOException {
            System.setProperty("sun.awt.noerasebackground", "true");
            CreateMenu Menu = new CreateMenu();
            Menu.showGUI();
            Menu.board.setVisible(true);
            Menu.difficulty=1;

            JLabel scoreLabel = new JLabel();                                   // Wyświetlanie timera na górze menu
            scoreLabel.setForeground(Color.WHITE);
            scoreLabel.setFont(new Font("Arial", Font.BOLD, 40));
            scoreLabel.setBounds(600, 25, 300, 50);
            Menu.pasek.add(scoreLabel);

            JLabel timerLabel = new JLabel();                                   // Wyświetlanie timera na górze menu
            timerLabel.setForeground(Color.WHITE);
            timerLabel.setFont(new Font("Arial", Font.BOLD, 40));
            timerLabel.setBounds(250, 25, 300, 50);
            Menu.pasek.add(timerLabel);
            startTime= System.currentTimeMillis();

            String imagePath1 = "/heart.jpg";
            InputStream url = Main.class.getResourceAsStream(imagePath1);

            try {
                BufferedImage heart = ImageIO.read(url);
                JLabel livesLabel = new JLabel(new ImageIcon(heart));
                livesLabel.setBounds(1000, 25, 100, 100);
                Menu.pasek.add(livesLabel);

            } catch (IOException e) {
                e.printStackTrace();
            }




            switch(Menu.difficulty){
                case 1:
                {
                 time_millis = 2000;
                }
                case 2:
                {
                    time_millis = 1000;
                }
                case 3:
                {
                    time_millis = 1000;
                }

            }


            while(end==false){          // end == true oznacza koniec gry i funkcję zakończenia rozgrywki

                updateTimer(timerLabel);
                updateScore(scoreLabel);
                Menu.clickableDrawing();
                try {
                    Thread.sleep(time_millis);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
               /*ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();
                executorService.scheduleWithFixedDelay(() -> {
                    try {
                        // Code to be executed periodically with a delay
                        System.out.println("Periodic task executed!");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }, time_millis, time_millis, TimeUnit.MILLISECONDS);*/

                                // Rysuje czerwone klikalne pole
                score++;
            }
            endGame();

        }

    public static void updateTimer(JLabel timerLabel) {
        long elapsedTime = System.currentTimeMillis() - startTime;
        long seconds = elapsedTime / 1000;
        long minutes = seconds / 60;

        SimpleDateFormat sdf = new SimpleDateFormat("mm:ss");
        String formattedTime = sdf.format(elapsedTime);

        SwingUtilities.invokeLater(() -> {
            timerLabel.setText("Czas: " + formattedTime);
            timerLabel.repaint();
        });
    }

    public static void updateScore(JLabel scoreLabel){
        scoreLabel.setText("Wynik: "+ score);
    }

}
